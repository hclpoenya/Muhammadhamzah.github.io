$(function () {

    $('.hps_logo').on('click', function () {
        // console.log('hapus');
        $('input[name="name_logo"]').val("");
    });

    $('.hps_logo_white').on('click', function () {
        // console.log('hapus');
        $('input[name="name_logo_white"]').val("");
    });


     $('.hps_icon').on('click', function () {
        // console.log('hapus');
        $('input[name="name_icon"]').val("");
    });

    $('.hps_icon_white').on('click', function () {
        // console.log('hapus');
        $('input[name="name_icon_white"]').val("");
    });

    

});