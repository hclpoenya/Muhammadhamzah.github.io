<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ReportDetail extends Model
{
    use HasFactory;

    protected $table = 'report_details';
    protected $primaryKey = 'id_report_detail';
    public $timestamps = false;

    protected $fillable = [
        'id_report',
        'file',
        'created_at',
        'updated_at',
    ];

    // Relasi ke report
    public function report()
    {
        return $this->belongsTo(Report::class, 'id_report', 'id_report');
    }
}
