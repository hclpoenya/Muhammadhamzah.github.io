<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Report extends Model
{
    use HasFactory;

    protected $table = 'reports';
    protected $primaryKey = 'id_report';
    public $timestamps = false;

    protected $fillable = [
        'id_category',
        'id_user',
        'name_1',
        'name_2',
        'place',
        'date',
        'description',
        'created_at',
        'updated_at'
    ];

    // Relasi ke kategori
    public function category()
    {
        return $this->belongsTo(Category::class, 'id_category', 'id_category');
    }

    // Relasi ke user
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user', 'id_user');
    }

    // Relasi ke report_details
    public function details()
    {
        return $this->hasMany(ReportDetail::class, 'id_report', 'id_report');
    }
}
