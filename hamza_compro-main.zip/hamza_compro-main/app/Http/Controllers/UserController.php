<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Validator;


use App\Models\User;
use App\Models\Category;
use App\Models\Contact;
use App\Models\Report;
use App\Models\ReportDetail;


class UserController extends Controller
{
    //

    public function index()
    {
        // SET TITLE
        $data['title'] = 'Home';

        // GET DATA
        $category = Category::where('status','Y')->where('deleted','N')->get();

        // SET DATA
        $data['category'] = $category;

        return view('user.index',$data);
    }

    public function pengaduan()
    {
        $prefix = config('session.prefix');
        $id_user = Session::get("{$prefix}_id_user");
        if (!$id_user) {
            return redirect('/home');
        }
        // SET TITLE
        $data['title'] = 'Pengaduan';

        // GET DATA
        $category = Category::where('status','Y')->where('deleted','N')->get();

        // SET DATA
        $data['category'] = $category;

        return view('user.pengaduan',$data);
    }


    public function insert_contact(Request $request)
    {
        $arrVar = [
            'name' => 'Nama',
            'email' => 'Alamat email',
            'message' => 'Pesan',
        ];

        $data = ['required' => [], 'arrAccess' => []];
        $post = [];

        // Validasi input satu per satu (sesuai dengan logika CI3-mu)
        foreach ($arrVar as $var => $label) {
            $$var = $request->input($var);
            if (!$$var) {
                $data['required'][] = ['req_contact_' . $var, "$label tidak boleh kosong!"];
                $data['arrAccess'][] = false;
            } else {
                $post[$var] = trim($$var);
                $data['arrAccess'][] = true;
            }
        }

        // Jika ada input yang kosong, return error
        if (in_array(false, $data['arrAccess'])) {
            return response()->json(['status' => false, 'required' => $data['required']]);
        }

        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return response()->json([
                'status' => 700,
                'alert' => ['message' => 'Invalid email address!']
            ]);
        }

        // Insert ke database
        $insert = Contact::create($post);

        if ($insert) {
            return response()->json([
                'status' => true,
                'alert' => ['message' => 'Berhasil menambahkan pesan baru!'],
                'reload' => true
            ]);
        }

        return response()->json([
            'status' => false,
            'alert' => ['message' => 'Gagal menambahkan pesan!'],
        ]);
    }


    public function submit_report(Request $request)
    {
        $arrVar = [
            'id_category' => 'Kategori',
            'name_1' => 'Nama terlapor 1',
            'name_2' => 'Nama terlapor 2',
            'place' => 'Tempat kejadian',
            'date' => 'Tanggal',
            'description' => 'Kronologi'
        ];

        $post = [];
        $arrAccess = [];
        $data = [];

        foreach ($arrVar as $var => $value) {
            $$var = $request->input($var);
            if (!$$var) {
                $data['required'][] = ['req_' . $var, "$value tidak boleh kosong!"];
                $arrAccess[] = false;
            } else {
                $post[$var] = trim($$var);
                $arrAccess[] = true;
            }
        }

        if (in_array(false, $arrAccess)) {
            return response()->json(['status' => false, 'required' => $data['required']]);
        }

        // 🔎 Cek file tersedia dan valid
        $validFiles = [];
        if ($request->hasFile('file')) {
            foreach ($request->file('file') as $file) {
                if ($file->isValid()) {
                    $ext = strtolower($file->getClientOriginalExtension());
                    if (in_array($ext, ['jpg', 'jpeg', 'png', 'pdf','docx'])) {
                        $validFiles[] = $file;
                    }
                }
            }
        }

        if (count($validFiles) === 0) {
            return response()->json([
                'status' => false,
                'alert' => ['message' => 'Minimal 1 file valid (jpg/png/pdf/docx) wajib diunggah!']
            ]);
        }

        $prefix = config('session.prefix');
        $id_user = session($prefix.'_id_user');
        $post['id_user'] = $id_user;

        $insert = Report::create($post);

        if ($insert) {
            $tujuan = public_path('data/report/');
            if (!File::exists($tujuan)) {
                File::makeDirectory($tujuan, 0755, true, true);
            }

            foreach ($validFiles as $file) {
                $fileName = uniqid() . '.' . $file->getClientOriginalExtension();
                $file->move($tujuan, $fileName);

                ReportDetail::create([
                    'id_report' => $insert->id_report,
                    'file' => $fileName
                ]);
            }

            return response()->json([
                'status' => true,
                'alert' => ['message' => 'Berhasil menambah laporan'],
                'reload' => true
            ]);
        }

        return response()->json([
            'status' => false,
            'alert' => ['message' => 'Gagal menambah laporan!']
        ]);
    }



}
