<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\File;
use Carbon\Carbon;
 use Illuminate\Database\Eloquent\Builder;



use App\Models\User;
use App\Models\Category;
use App\Models\Contact;
use App\Models\Report;

class TableManagement extends Controller
{



    public function table_user(Request $request)
    {
        $search = $request->search['value'] ?? '';
        $start = (int)($request->start ?? 0);
        $length = (int)($request->length ?? 10);
        $orderColumn = $request->order[0]['column'] ?? null;
        $orderDir = $request->order[0]['dir'] ?? 'asc';
        $today = Carbon::today()->toDateString();
        $prefix = config('session.prefix');
        $id_user = session($prefix.'_id_user');

        // Kolom mapping sesuai urutan di frontend DataTables
        $columns = [
            null,   
            'users.name',
            'users.email',       
            'users.status',          
        ];

        $query = User::select(     
                    'users.id_user',   
                    'users.name',     
                    'users.email',  
                    'users.status', 
                    'users.image'   
                )->where('users.id_user','!=',$id_user)
                ->where('users.role',2);
        // Search
        if (!empty($search)) {
            $query->where(function ($q) use ($search) {
                $q->where('users.name', 'like', "%{$search}%")
                ->orWhere('users.email', 'like', "%{$search}%");
            });
        }

        // Sorting
        if ($orderColumn !== null && isset($columns[$orderColumn])) {
            $query->orderBy($columns[$orderColumn], $orderDir);
        } else {
            $query->orderBy('users.created_at', 'DESC'); // Default sorting
        }

        if ($request->filter_status !== null && $request->filter_status !== '') {
            if ($request->filter_status != 'all') {
                $query->where('status', $request->filter_status);
            }
            
        }

        // Total record
        $totalRecords = $query->count();

        // Pagination
        $query->skip($start)->take($length);
        $data = $query->get();

        // Format output
        $result = [];
        foreach ($data as $item) {
            // GET USER
            $user = '';
            $user .= '<div class="d-flex align-items-center">';
            $user .= '<a role="button" class="symbol symbol-50px"><span class="symbol-label" style="background-image:url('.image_check($item->image,'user','user').');"></span></a>';
            $user .= '<div class="ms-5">';
            $user .= '<a role="button" class="text-gray-800 text-hover-primary fs-5 fw-bold">'.$item->name.'</a>';
            $user .= '</div></div>';

            // STATUS
            $checked = '';
            if ($item->status == 'Y') {
                $checked = 'checked';
            }
            $status = '';
            $status .= '<div class="d-flex justify-content-center align-items-center">';
            $status .= '<div class="form-check form-switch"><input onchange="switching(this,event,'.$item->id_user.')" data-primary="id_user"  data-url="'.url('switch/users').'" class="form-check-input cursor-pointer focus-info" type="checkbox" role="switch" id="switch-'.$item->id_user.'" '.$checked.'></div>';
            $status .= '</div>';

            $kontak = '';
                if ($item->email || $item->phone){
                    $kontak .= '<div class="d-flex justify-content-start flex-column">';
                    if ($item->email) {
                        $kontak .= '<span class="text-dark fw-bold text-hover-primary d-block fs-6"><i class="fa-solid fa-envelope" style="margin-right : 10px;"></i>'.$item->email.'</span>';
                    }
                    if ($item->phone){
                        $kontak .= '<span class="text-dark fw-bold text-hover-primary d-block fs-6"><i class="fa-solid fa-phone" style="margin-right : 10px;"></i>'.$item->phone.'</span>';
                    }
                    $kontak .= '</div>';
                }else{
                    $kontak .= '<span class="text-dark fw-bold text-hover-primary d-block fs-6"> - </span>';
                }
                
                $kontak = '';
                if ($item->email || $item->phone){
                    $kontak .= '<div class="d-flex justify-content-start flex-column">';
                    if ($item->email) {
                        $kontak .= '<span class="text-dark fw-bold text-hover-primary d-block fs-6"><i class="fa-solid fa-envelope" style="margin-right : 10px;"></i>'.$item->email.'</span>';
                    }
                    if ($item->phone){
                        $kontak .= '<span class="text-dark fw-bold text-hover-primary d-block fs-6"><i class="fa-solid fa-phone" style="margin-right : 10px;"></i>'.$item->phone.'</span>';
                    }
                    $kontak .= '</div>';
                }else{
                    $kontak .= '<span class="text-dark fw-bold text-hover-primary d-block fs-6"> - </span>';
                }
            

            // ACTION
            $action = '';
            $action .= '<div class="d-flex justify-content-end flex-shrink-0">
                            <button type="button" class="btn btn-icon btn-warning btn-sm me-1" title="Update" onclick="ubah_data(this,'.$item->id_user.')" data-image="'.image_check($item->image,'user','user').'" data-bs-toggle="modal" data-bs-target="#kt_modal_user">
                                <i class="ki-outline ki-pencil fs-2"></i>
                            </button>
                            <button type="button" onclick="hapus_data(this,event,'.$item->id_user.',`users`,`id_user`)" data-datatable="table_user" class="btn btn-icon btn-danger btn-sm" title="Delete">
                                <i class="ki-outline ki-trash fs-2"></i>
                            </button>
                        </div>';

            
            $result[] = [
                $user,
                $kontak,
                $status,
                $action
            ];
        }

        $return = [
            'draw' => intval($request->draw),
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $totalRecords,
            'data' => $result // langsung isi array row di sini
        ];

        return response()->json($return);

        
    }

    public function table_admin(Request $request)
    {
        $search = $request->search['value'] ?? '';
        $start = (int)($request->start ?? 0);
        $length = (int)($request->length ?? 10);
        $orderColumn = $request->order[0]['column'] ?? null;
        $orderDir = $request->order[0]['dir'] ?? 'asc';
        $today = Carbon::today()->toDateString();
        $prefix = config('session.prefix');
        $id_user = session($prefix.'_id_user');

        // Kolom mapping sesuai urutan di frontend DataTables
        $columns = [
            null,   
            'users.name',   
            'users.email',    
            'users.status',          
        ];

        $query = User::select(     
                    'users.id_user',   
                    'users.name',     
                    'users.email',  
                    'users.status', 
                    'users.image'   
                )->where('users.id_user','!=',$id_user)
                ->where('users.role',1);
        // Search
        if (!empty($search)) {
            $query->where(function ($q) use ($search) {
                $q->where('users.name', 'like', "%{$search}%")
                ->orWhere('users.email', 'like', "%{$search}%");
            });
        }

        // Sorting
        if ($orderColumn !== null && isset($columns[$orderColumn])) {
            $query->orderBy($columns[$orderColumn], $orderDir);
        } else {
            $query->orderBy('users.created_at', 'DESC'); // Default sorting
        }

        if ($request->filter_status !== null && $request->filter_status !== '') {
            if ($request->filter_status != 'all') {
                $query->where('status', $request->filter_status);
            }
            
        }

        // Total record
        $totalRecords = $query->count();

        // Pagination
        $query->skip($start)->take($length);
        $data = $query->get();

        // Format output
        $result = [];
        foreach ($data as $item) {
            // GET USER
            $user = '';
            $user .= '<div class="d-flex align-items-center">';
            $user .= '<a role="button" class="symbol symbol-50px"><span class="symbol-label" style="background-image:url('.image_check($item->image,'user','user').');"></span></a>';
            $user .= '<div class="ms-5">';
            $user .= '<a role="button" class="text-gray-800 text-hover-primary fs-5 fw-bold">'.$item->name.'</a>';
            $user .= '<span class="text-muted fw-bold text-hover-primary d-block fs-6"><i class="fa-solid fa-envelope" style="margin-right : 5px;"></i>'.$item->email.'</span>';
            $user .= '</div></div>';

            // STATUS
            $checked = '';
            if ($item->status == 'Y') {
                $checked = 'checked';
            }
            $status = '';
            $status .= '<div class="d-flex justify-content-center align-items-center">';
            $status .= '<div class="form-check form-switch"><input onchange="switching(this,event,'.$item->id_user.')" data-primary="id_user"  data-url="'.url('switch/users').'" class="form-check-input cursor-pointer focus-info" type="checkbox" role="switch" id="switch-'.$item->id_user.'" '.$checked.'></div>';
            $status .= '</div>';

            $kontak = '';
            if ($item->email || $item->phone){
                $kontak .= '<div class="d-flex justify-content-start flex-column">';
                if ($item->email) {
                    $kontak .= '<span class="text-dark fw-bold text-hover-primary d-block fs-6"><i class="fa-solid fa-envelope" style="margin-right : 10px;"></i>'.$item->email.'</span>';
                }
                if ($item->phone){
                    $kontak .= '<span class="text-dark fw-bold text-hover-primary d-block fs-6"><i class="fa-solid fa-phone" style="margin-right : 10px;"></i>'.$item->phone.'</span>';
                }
                $kontak .= '</div>';
            }else{
                $kontak .= '<span class="text-dark fw-bold text-hover-primary d-block fs-6"> - </span>';
            }
            

            // ACTION
            $action = '';
            $action .= '<div class="d-flex justify-content-end flex-shrink-0">
                            <button type="button" class="btn btn-icon btn-warning btn-sm me-1" title="Update" onclick="ubah_data(this,'.$item->id_user.')" data-image="'.image_check($item->image,'user','user').'" data-bs-toggle="modal" data-bs-target="#kt_modal_admin">
                                <i class="ki-outline ki-pencil fs-2"></i>
                            </button>
                            <button type="button" onclick="hapus_data(this,event,'.$item->id_user.',`users`,`id_user`)" data-datatable="table_admin" class="btn btn-icon btn-danger btn-sm" title="Delete">
                                <i class="ki-outline ki-trash fs-2"></i>
                            </button>
                        </div>';

            
            $result[] = [
                $user,
                $kontak,
                $status,
                $action
            ];
        }

        $return = [
            'draw' => intval($request->draw),
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $totalRecords,
            'data' => $result // langsung isi array row di sini
        ];

        return response()->json($return);

        
    }


    public function table_category(Request $request)
    {
        $search = $request->search['value'] ?? '';
        $start = (int)($request->start ?? 0);
        $length = (int)($request->length ?? 10);
        $orderColumn = $request->order[0]['column'] ?? null;
        $orderDir = $request->order[0]['dir'] ?? 'asc';
        $today = Carbon::today()->toDateString();
        $prefix = config('session.prefix');
        $id_user = session($prefix.'_id_user');

        // Kolom mapping sesuai urutan di frontend DataTables
        $columns = [
            null,   
            'categories.name',    
            'categories.status',         
        ];

        $query = Category::where('deleted','N');
        // Search
        if (!empty($search)) {
            $query->where(function ($q) use ($search) {
                $q->where('categories.name', 'like', "%{$search}%");
            });
        }

        // Sorting
        if ($orderColumn !== null && isset($columns[$orderColumn])) {
            $query->orderBy($columns[$orderColumn], $orderDir);
        } else {
            $query->orderBy('categories.created_at', 'DESC'); // Default sorting
        }

        if ($request->filter_status !== null && $request->filter_status !== '') {
            if ($request->filter_status != 'all') {
                $query->where('status', $request->filter_status);
            }
            
        }

        // Total record
        $totalRecords = $query->count();

        // Pagination
        $query->skip($start)->take($length);
        $data = $query->get();

        // Format output
        $result = [];
        foreach ($data as $item) {
            // STATUS
            $checked = '';
            if ($item->status == 'Y') {
                $checked = 'checked';
            }
            $status = '';
            $status .= '<div class="d-flex justify-content-center align-items-center">';
            $status .= '<div class="form-check form-switch"><input onchange="switching(this,event,'.$item->id_category.')" data-primary="id_category"  data-url="'.url('switch/categories').'" class="form-check-input cursor-pointer focus-info" type="checkbox" role="switch" id="switch-'.$item->id_category.'" '.$checked.'></div>';
            $status .= '</div>';
            

            // ACTION
            $action = '';
            $action .= '<div class="d-flex justify-content-end flex-shrink-0">
                            <button type="button" class="btn btn-icon btn-warning btn-sm me-1" title="Update" onclick="ubah_data(this,'.$item->id_category.')" data-bs-toggle="modal" data-bs-target="#kt_modal_category">
                                <i class="ki-outline ki-pencil fs-2"></i>
                            </button>
                            <button type="button" onclick="hapus_data(this,event,'.$item->id_category.',`categories`,`id_category`)" data-datatable="table_category" class="btn btn-icon btn-danger btn-sm" title="Delete">
                                <i class="ki-outline ki-trash fs-2"></i>
                            </button>
                        </div>';

            
            $result[] = [
                $item->name,
                $status,
                $action
            ];
        }

        $return = [
            'draw' => intval($request->draw),
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $totalRecords,
            'data' => $result // langsung isi array row di sini
        ];

        return response()->json($return);

        
    }


    public function table_contact(Request $request)
    {
        $search = $request->search['value'] ?? '';
        $start = (int)($request->start ?? 0);
        $length = (int)($request->length ?? 10);
        $orderColumn = $request->order[0]['column'] ?? null;
        $orderDir = $request->order[0]['dir'] ?? 'asc';
        $today = Carbon::today()->toDateString();
        $prefix = config('session.prefix');
        $id_user = session($prefix.'_id_user');

        // Kolom mapping sesuai urutan di frontend DataTables
        $columns = [
            null,   
            'contacts.name',  
            'contacts.email',  
            'contacts.message',           
        ];

        $query = Contact::where('id_contact','>=',1);
        // Search
        if (!empty($search)) {
            $query->where(function ($q) use ($search) {
                $q->where('contacts.name', 'like', "%{$search}%")
                ->orWhere('contacts.email', 'like', "%{$search}%")
                ->orWhere('contacts.message', 'like', "%{$search}%");
            });
        }

        // Sorting
        if ($orderColumn !== null && isset($columns[$orderColumn])) {
            $query->orderBy($columns[$orderColumn], $orderDir);
        } else {
            $query->orderBy('contacts.created_at', 'DESC'); // Default sorting
        }

        // Total record
        $totalRecords = $query->count();

        // Pagination
        $query->skip($start)->take($length);
        $data = $query->get();

        // Format output
        $result = [];
        foreach ($data as $item) {

            // ACTION
            $action = '';
            $action .= '<div class="d-flex justify-content-end flex-shrink-0">
                            <button type="button" onclick="hapus_data(this,event,'.$item->id_contact.',`contacts`,`id_contact`)" data-datatable="table_contact" class="btn btn-icon btn-danger btn-sm" title="Delete">
                                <i class="ki-outline ki-trash fs-2"></i>
                            </button>
                        </div>';

            
            $result[] = [
                $item->name,
                $item->email,
                $item->message,
                $action
            ];
        }

        $return = [
            'draw' => intval($request->draw),
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $totalRecords,
            'data' => $result // langsung isi array row di sini
        ];

        return response()->json($return);

        
    }

    
    
    public function table_report(Request $request)
    {
        $search = $request->search['value'] ?? '';
        $start = (int)($request->start ?? 0);
        $length = (int)($request->length ?? 10);
        $orderColumn = $request->order[0]['column'] ?? null;
        $orderDir = $request->order[0]['dir'] ?? 'asc';
        $prefix = config('session.prefix');
        $id_user = session($prefix . '_id_user');

        // Mapping kolom untuk DataTables
        $columns = [
            null,
            'users.name',
            'categories.name',
            'reports.name_1',
            'reports.name_2',
            'reports.place',
            'reports.date',
            'reports.created_at',
        ];

        // Query utama dengan join dan eager loading
        $query = Report::query()
            ->select('reports.*')
            ->join('users', 'users.id_user', '=', 'reports.id_user')
            ->join('categories', 'categories.id_category', '=', 'reports.id_category')
            ->with(['user', 'category']);

        // Search global
        if (!empty($search)) {
            $query->where(function ($q) use ($search) {
                $q->where('reports.name_1', 'like', "%{$search}%")
                ->orWhere('reports.name_2', 'like', "%{$search}%")
                ->orWhere('reports.place', 'like', "%{$search}%")
                ->orWhere('reports.description', 'like', "%{$search}%")
                ->orWhere('users.name', 'like', "%{$search}%")
                ->orWhere('users.email', 'like', "%{$search}%")
                ->orWhere('categories.name', 'like', "%{$search}%");
            });
        }

        // Hitung total setelah filter
        $filteredCount = (clone $query)->count();

        // Sorting
        if ($orderColumn !== null && isset($columns[$orderColumn])) {
            $query->orderBy($columns[$orderColumn], $orderDir);
        } else {
            $query->orderBy('reports.created_at', 'DESC');
        }

        // Ambil data untuk halaman ini
        $data = $query->skip($start)->take($length)->get();

        // Format hasil
        $result = [];
        foreach ($data as $item) {
            // USER
            $user = '<div class="d-flex align-items-center">';
            $user .= '<a role="button" class="symbol symbol-50px">';
            $user .= '<span class="symbol-label" style="background-image:url('.image_check($item->user->image, 'user', 'user').');"></span>';
            $user .= '</a>';
            $user .= '<div class="ms-5 d-flex flex-column">';
            $user .= '<a role="button" class="text-primary fs-5 fw-bold mb-1">'.$item->user->name.'</a>';
            $user .= '<a role="button" class="text-gray-800 text-hover-primary fs-6">'.$item->user->email.'</a>';
            $user .= '</div></div>';

            // ACTION
            $action = '<div class="d-flex justify-content-center align-items-center flex-shrink-0">
                <button type="button" onclick="detail_data('.$item->id_report.')" class="btn btn-icon btn-info btn-sm me-1" title="Detail Info" data-bs-toggle="modal" data-bs-target="#kt_modal_detail">
                    <i class="fa-solid fa-info fs-2"></i>
                </button>
                <button type="button" onclick="hapus_data(this,event,'.$item->id_report.',`reports`,`id_report`)" data-datatable="table_contact" class="btn btn-icon btn-danger btn-sm ms-1" title="Delete">
                    <i class="ki-outline ki-trash fs-2"></i>
                </button>
            </div>';

            $result[] = [
                $action,
                $user,
                $item->category->name ?? '-',
                $item->name_1,
                $item->name_2,
                $item->place,
                date('d M Y', strtotime($item->date)),
                date('d M Y', strtotime($item->created_at)),
            ];
        }

        // Total semua data (tanpa filter)
        $totalRecords = Report::count();

        return response()->json([
            'draw' => intval($request->draw),
            'recordsTotal' => $totalRecords,
            'recordsFiltered' => $filteredCount,
            'data' => $result,
        ]);
    }



}
