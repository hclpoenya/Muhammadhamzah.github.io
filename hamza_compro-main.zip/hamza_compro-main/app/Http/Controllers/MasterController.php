<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Session;
use Carbon\Carbon;
use Illuminate\Support\Facades\File;


use App\Models\User;
use App\Models\Category;

class MasterController extends Controller
{

    // GET VIEW
    public function user()
    {
        // SET TITLE
        $data['title'] = 'Master Users';
        $data['subtitle'] = 'Users management';

        return view('admin.master.user',$data);
    }

    public function admin()
    {
        // SET TITLE
        $data['title'] = 'Master Admins';
        $data['subtitle'] = 'Admins management';

        return view('admin.master.admin',$data);
    }

    public function category()
    {
        // SET TITLE
        $data['title'] = 'Master Categories';
        $data['subtitle'] = 'Categories management';

        return view('admin.master.category',$data);
    }



    // POST FUNCTION


    // // USER
    public function insert_user(Request $request)
    {
        $arrVar = [
            'name' => 'Full name',
            'email' => 'Email address',
            'phone' => 'Phone number',
            'password' => 'Password',
            'repassword' => 'Password confirmation',
            'role' => 'Peran'
        ];

        $post = [];
        $arrAccess = [];
        $data = [];

        foreach ($arrVar as $var => $value) {
            $$var = $request->input($var);
            if (!$$var) {
                $data['required'][] = ['req_' . $var, "$value cannot be empty!"];
                $arrAccess[] = false;
            } else {
                if (!in_array($var, ['password', 'repassword'])) {
                    $post[$var] = trim($$var);
                    $arrAccess[] = true;
                }
            }
        }

        if (in_array(false, $arrAccess)) {
            return response()->json(['status' => false, 'required' => $data['required']]);
        }
        
        $tujuan = public_path('data/user/');
        if (!File::exists($tujuan)) {
            File::makeDirectory($tujuan, 0755, true, true);
        }
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
            $image->move($tujuan, $fileName);
            
            $post['image'] = $fileName;
        }

        if (!filter_var($request->email, FILTER_VALIDATE_EMAIL)) {
            return response()->json([
                'status' => 700,
                'alert' => ['message' => 'Invalid email address!']
            ]);
        }

        if (User::where('email', $request->email)->where('deleted', 'N')->exists()) {
            return response()->json([
                'status' => false,
                'alert' => ['message' => 'Email address is already registered!']
            ]);
        }

        if ($request->password !== $request->repassword) {
            return response()->json([
                'status' => false,
                'alert' => ['message' => 'Password confirmation does not match!']
            ]);
        }

        $prefix = config('session.prefix');
        $id_user = session($prefix.'_id_user');
    
        $page = 'user';
        if ($role == 1) {
            $page = "admin";
        }

        $post['password'] = $request->password;
        $post['created_by'] = $id_user;

        $insert = User::create($post);

        if ($insert) {
            return response()->json([
                'status' => true,
                'alert' => ['message' => 'Data added successfully!'],
                'datatable' => 'table_'.$page,
                'modal' => ['id' => '#kt_modal_'.$page, 'action' => 'hide'],
                'input' => ['all' => true]
            ]);
        } else {
            return response()->json([
                'status' => false,
                'alert' => ['message' => 'Failed to add data!']
            ]);
        }
    }

    public function update_user(Request $request)
    {
        $id = $request->id_user;
        $user = User::where('id_user', $id)->where('deleted', 'N')->first();

        if (!$user) {
            return response()->json([
                'status' => false,
                'alert' => ['message' => 'User not found!']
            ]);
        }

        $arrVar = [
            'name' => 'Full name',
            'phone' => 'Phone number',
            'email' => 'Email address',
            'role' => 'Peran'
        ];

        $post = [];
        $arrAccess = [];
        $data = [];

        foreach ($arrVar as $var => $value) {
            $$var = $request->input($var);
            if (!$$var) {
                $data['required'][] = ['req_' . $var, "$value cannot be empty!"];
                $arrAccess[] = false;
            } else {
                $post[$var] = trim($$var);
                $arrAccess[] = true;
            }
        }

        if (in_array(false, $arrAccess)) {
            return response()->json(['status' => false, 'required' => $data['required']]);
        }
        // Cek duplikat email (exclude current user)
        if (!filter_var($request->email, FILTER_VALIDATE_EMAIL)) {
            return response()->json([
                'status' => 700,
                'alert' => ['message' => 'Invalid email address!']
            ]);
        }

        if (User::where('email', $request->email)->where('id_user', '!=', $id)->where('deleted', 'N')->exists()) {
            return response()->json([
                'status' => false,
                'alert' => ['message' => 'Email address is already used by another user!']
            ]);
        }

        // Jika password diisi, validasi dan hash
        if ($request->filled('password')) {
            if ($request->password !== $request->repassword) {
                return response()->json([
                    'status' => false,
                    'alert' => ['message' => 'Password confirmation does not match!']
                ]);
            }
            $post['password'] = $request->password;
        }

        $tujuan = public_path('data/user/');
        $name_image = $request->name_image;
        if (!File::exists($tujuan)) {
            File::makeDirectory($tujuan, 0755, true, true);
        }
        if ($request->hasFile('image')) {
            $image = $request->file('image');
            $fileName = uniqid() . '.' . $image->getClientOriginalExtension();
            $image->move($tujuan, $fileName);
            
            if ($user->image && file_exists($tujuan . $user->image)) {
                unlink($tujuan . $user->image);
            }
            
            $post['image'] = $fileName;
        } elseif (!$name_image) {
            if ($user->image && file_exists($tujuan . $user->image)) {
                unlink($tujuan . $user->image);
            }
            $post['image'] = null;
        }

        $page = 'user';
        if ($role == 1) {
            $page = "admin";
        }

        $update = $user->update($post);

        if ($update) {
            return response()->json([
                'status' => true,
                'alert' => ['message' => 'updated successfully!'],
                'datatable' => 'table_'.$page,
                'modal' => ['id' => '#kt_modal_'.$page, 'action' => 'hide'],
                'input' => ['all' => true]
            ]);
        } else {
            return response()->json([
                'status' => false,
                'alert' => ['message' => 'Failed to update!']
            ]);
        }
        

        return response()->json(['status' => false]);
    }




    // // CATEGORY
    public function insert_category(Request $request)
    {
        $arrVar = [
            'name' => 'Category',
        ];

        $post = [];
        $arrAccess = [];
        $data = [];

        foreach ($arrVar as $var => $value) {
            $$var = $request->input($var);
            if (!$$var) {
                $data['required'][] = ['req_' . $var, "$value cannot be empty!"];
                $arrAccess[] = false;
            } else {
                $post[$var] = trim($$var);
                $arrAccess[] = true;
            }
        }

        if (in_array(false, $arrAccess)) {
            return response()->json(['status' => false, 'required' => $data['required']]);
        }

        $prefix = config('session.prefix');
        $id_user = session($prefix.'_id_user');
    
        $post['created_by'] = $id_user;

        $insert = Category::create($post);

        if ($insert) {
            return response()->json([
                'status' => true,
                'alert' => ['message' => 'Data added successfully!'],
                'datatable' => 'table_category',
                'modal' => ['id' => '#kt_modal_category', 'action' => 'hide'],
                'input' => ['all' => true]
            ]);
        } else {
            return response()->json([
                'status' => false,
                'alert' => ['message' => 'Failed to add data!']
            ]);
        }
    }

    public function update_category(Request $request)
    {
        $id = $request->id_category;
        $category = Category::where('id_category', $id)->where('deleted', 'N')->first();

        if (!$category) {
            return response()->json([
                'status' => false,
                'alert' => ['message' => 'Category not found!']
            ]);
        }

        $arrVar = [
            'name' => 'Category'
        ];

        $post = [];
        $arrAccess = [];
        $data = [];

        foreach ($arrVar as $var => $value) {
            $$var = $request->input($var);
            if (!$$var) {
                $data['required'][] = ['req_' . $var, "$value cannot be empty!"];
                $arrAccess[] = false;
            } else {
                $post[$var] = trim($$var);
                $arrAccess[] = true;
            }
        }

        if (in_array(false, $arrAccess)) {
            return response()->json(['status' => false, 'required' => $data['required']]);
        }

        $update = $category->update($post);

        if ($update) {
            return response()->json([
                'status' => true,
                'alert' => ['message' => 'updated successfully!'],
                'datatable' => 'table_category',
                'modal' => ['id' => '#kt_modal_category', 'action' => 'hide'],
                'input' => ['all' => true]
            ]);
        } else {
            return response()->json([
                'status' => false,
                'alert' => ['message' => 'Failed to update!']
            ]);
        }
        

        return response()->json(['status' => false]);
    }


}
