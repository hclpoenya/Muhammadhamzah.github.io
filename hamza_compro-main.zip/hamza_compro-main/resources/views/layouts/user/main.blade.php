<!DOCTYPE html>
<html lang="en">
@include('partials.user.header') <!-- Panggil head dari partial -->

<body class="background-partisi">
    @include('partials.user.navbar')

    <main id="main" class="background-partisi">
        @yield('content')
    </main>

    @include('partials.user.footer')

    <a href="#" class="back-to-top"><i class="fa fa-chevron-up"></i></a>

    @include('partials.user.tail')

</body>

</html>