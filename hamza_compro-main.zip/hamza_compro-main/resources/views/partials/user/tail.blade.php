

<script>
    var BASE_URL = "{{ url('/') }}";
    var hostUrl = "{{ asset('assets/user/') }}";
    var css_btn_confirm = 'btn btn-primary mx-1';
    var css_btn_cancel = 'btn btn-danger mx-1';
    var csrf_token = "{{ csrf_token() }}";
</script>

<!-- JavaScript Libraries -->
  <!-- Waves Effect Plugin Js -->
  <script src="https://whistleblowing.inka.co.id/adminbsb/plugins/node-waves/waves.js"></script>

  <!-- Moment Plugin Js -->
  <script src="https://whistleblowing.inka.co.id/adminbsb/plugins/momentjs/moment.js"></script>

  <!-- Bootstrap Material Datetime Picker Plugin Js -->
  <script src="https://whistleblowing.inka.co.id/adminbsb/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script>

  <script type="text/javascript">
    $(function () {
      $('.datepicker').bootstrapMaterialDatePicker({
        format: 'YYYY-MM-DD',
        time: false
      });
    });
  </script>

    <script src="{{ asset('assets/user/avilon/js/sweetalert.min.js') }}"></script>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

    <script src="{{ asset('assets/user/avilon/lib/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('assets/user/avilon/lib/jquery/jquery-migrate.min.js') }}"></script>
    <script src="{{ asset('assets/user/avilon/lib/easing/easing.min.js') }}"></script>
    <script src="{{ asset('assets/user/avilon/lib/wow/wow.min.js') }}"></script>
    <script src="{{ asset('assets/user/avilon/lib/superfish/hoverIntent.js') }}"></script>
    <script src="{{ asset('assets/user/avilon/lib/superfish/superfish.min.js') }}"></script>
    <script src="{{ asset('assets/user/avilon/lib/magnific-popup/magnific-popup.min.js') }}"></script>

    <!-- Contact Form JavaScript File -->
    <script src="{{ asset('assets/user/avilon/contactform/contactform.js') }}"></script>

    <!-- Template Main Javascript File -->
    <script src="{{ asset('assets/user/avilon/js/main.js') }}"></script>

    <script src="{{ asset('assets/public/js/mekanik.js') }}"></script>
    <script src="{{ asset('assets/public/js/function.js') }}"></script>
    <script src="{{ asset('assets/public/js/global.js') }}"></script>
    <script src="{{ asset('assets/public/js/alert/sweetalert2.min.js') }}"></script>
    <script src="{{ asset('assets/public/js/select2.min.js') }}"></script>
    <script src="{{ asset('assets/public/js/custom-datatable.js') }}"></script>


<script>

  function toAuth(to,from) {
        $(to).removeClass('d-none');
        $(from).addClass('d-none');
  }

    document.addEventListener("DOMContentLoaded", function() {
        document.querySelectorAll(".toggle-password").forEach(function(toggle) {
            toggle.addEventListener("click", function() {
                const targetId = this.getAttribute("data-target");
                const input = document.getElementById(targetId);
                const icon = this.querySelector("i");

                if (input.type === "password") {
                    input.type = "text";
                    icon.classList.remove("fa-eye-slash");
                    icon.classList.add("fa-eye");
                } else {
                    input.type = "password";
                    icon.classList.remove("fa-eye");
                    icon.classList.add("fa-eye-slash");
                }
            });
        });
    });

    $(document).ready(function() {
        $(document).ready(function() {
            $('.select2-style').select2({
                theme: 'bootstrap-5',
                placeholder: $(this).data('placeholder'),
            });
        });
    });

</script>

@stack('script')
