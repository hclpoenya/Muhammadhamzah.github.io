<head>
    <meta charset="utf-8">
    <title>{{ (isset($setting->meta_title) && !empty($setting->meta_title)) ? ucfirst($setting->meta_title) : '' }}{{ isset($title) ? ' | '.$title : '' }}</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700|Open+Sans:300,300i,400,400i,700,700i" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
  
     <link rel="icon" href="{{ image_check($setting->icon ?? 'default-icon.png', 'setting') }}?v={{ time() }}" type="image/x-icon">

    <link href="https://fonts.googleapis.com/css?family=Montserrat:300,400,500,700|Open+Sans:300,300i,400,400i,700,700i"
        rel="stylesheet">

    <!-- Bootstrap CSS File -->
    <link href="{{ asset('assets/user/avilon/lib/bootstrap/css/bootstrap.min.css') }}" rel="stylesheet">

    <!-- Selectize Css -->
    <link href="{{ asset('assets/user/avilon/css/selectize.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/user/avilon/css/selectize.bootstrap3.css') }}" rel="stylesheet">

    <!-- Libraries CSS Files -->
    <link href="{{ asset('assets/user/avilon/lib/animate/animate.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/user/avilon/lib/font-awesome/css/font-awesome.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/user/avilon/lib/ionicons/css/ionicons.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/user/avilon/lib/magnific-popup/magnific-popup.css') }}" rel="stylesheet">

    <!-- Main Stylesheet File -->
    <link href="{{ asset('assets/user/avilon/css/style.css') }}" rel="stylesheet">

    <!-- Sweet Alert -->
    <link href="{{ asset('assets/user/avilon/css/sweetalert.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.7.2/css/all.min.css">

    <link href="{{ asset('assets/public/js/alert/sweetalert2.min.css') }}" rel="stylesheet">
     <link href="{{ asset('assets/public/css/select2.min.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/public/css/select2_bs.css') }}" rel="stylesheet">

    @stack('styles')
</head>