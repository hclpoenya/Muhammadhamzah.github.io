<footer id="footer">
    <div class="container">
        <div class="row">
            <div class="col-lg-6 text-lg-left text-center">
                <div class="copyright">
                    &copy; Copyright <strong>Avilon</strong>. All Rights Reserved
                </div>
                <div class="credits">
                    Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a>
                </div>
            </div>
        </div>
    </div>
</footer>


<div class="modal fade" id="modalLogin" data-bs-backdrop="static" data-bs-keyboard="false" aria-hidden="true" aria-labelledby="modalLoginLabel" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content rounded">
            <div class="modal-body">
                <div class="w-100 position-absolute d-flex justify-content-end align-items-center px-4">
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><i class="fa-solid fa-xmark"></i></button>
                </div>
                <form id="formLogin" method="POST" action="{{ route('auth.login') }}" class="pt-5">
                    <div class="mb-3 text-center">
                        <h2 class="form-label">Login</h2>
                    </div>


                    <div class="mb-3" id="req_login_email">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" name="email" id="email" placeholder="Masukkan email Anda" autocomplete="off">
                    </div>

                    <div class="mb-3 position-relative" id="req_login_password">
                        <label for="password" class="form-label">Kata Sandi</label>
                        <div class="input-group">
                            <input type="password" class="form-control" name="password" id="password" placeholder="Masukkan kata sandi anda" autocomplete="off">
                            <span class="input-group-text toggle-password" data-target="password" style="cursor: pointer;">
                                <i class="fa-solid fa-eye-slash"></i>
                            </span>
                        </div>
                    </div>

                    <button onclick="submit_form(this,'#formLogin')" id="button_login" type="button" class="btn btn-primary w-100">Masuk</button>

                    <div class="text-center mt-3">
                        <p>Belum memiliki akun? <a role="button" onclick="toAuth('#formRegister','#formLogin')" class="text-primary">Daftar sekarang</a></p>
                    </div>
                </form>


                <form id="formRegister" class="pt-5 d-none" method="POST" action="{{ route('auth.register') }}">
                    <div class="mb-3 text-center">
                        <h2 class="form-label">Daftar</h2>
                    </div>

                    <div class="mb-3" id="req_name">
                        <label for="register-name" class="form-label">Nama Lengkap</label>
                        <input type="text" name="name" class="form-control" id="register-name" placeholder="Masukkan nama lengkap Anda" autocomplete="off">
                    </div>
                    <div class="mb-3" id="req_email">
                        <label for="register-email" class="form-label">Email</label>
                        <input type="email" name="email" class="form-control" id="register-email" placeholder="Masukkan email Anda" autocomplete="off">
                    </div>

                    <div class="mb-3" id="req_phone">
                        <label for="phone-number" class="form-label">Nomor Telpon</label>
                        <input type="phone-number" name="phone" class="form-control" id="register-email" placeholder="Masukkan nomor telepon Anda" autocomplete="off">
                    </div>


                    <div class="mb-3 position-relative" id="req_password">
                        <label for="password" class="form-label">Kata Sandi</label>
                        <div class="input-group">
                            <input type="password" class="form-control" name="password" id="regis_password" placeholder="Masukkan kata sandi anda" autocomplete="off">
                            <span class="input-group-text toggle-password" data-target="regis_password" style="cursor: pointer;">
                                <i class="fa-solid fa-eye-slash"></i>
                            </span>
                        </div>
                    </div>

                    <div class="mb-3 position-relative" id="req_repassword">
                        <label for="password" class="form-label">Konfirmasi Kata Sandi</label>
                        <div class="input-group">
                            <input type="password" class="form-control" name="repassword" id="regis_repassword" placeholder="Masukkan konfirmasi kata sandi anda" autocomplete="off">
                            <span class="input-group-text toggle-password" data-target="regis_repassword" style="cursor: pointer;">
                                <i class="fa-solid fa-eye-slash"></i>
                            </span>
                        </div>
                    </div>

                    <button role="button" id="button_register" onclick="submit_form(this,'#formRegister')" class="btn btn-primary w-100 text-white rounded-3 shadow-sm hover-shadow">Daftar</button>

                    


                    <div class="text-center mt-3">
                        <p>Sudah memiliki akun? <a role="button" class="text-primary"  onclick="toAuth('#formLogin','#formRegister')">Login di sini</a></p>
                    </div>

                </form>
            </div>
        </div>
    </div>
</div>