<header id="header" class="d-flex justify-content-center aling-items-center">
    <div class="container d-flex justify-content-between align-items-center">

        <div id="logo" class="pull-left">
            <a href="" target="_blank"><img src="{{ image_check($setting->logo,'setting') }}" width="180px" alt="" title=""></a>
        </div>

        <nav id="nav-menu-container">
            <ul class="nav-menu">
                <li class="menu-active"><a href="{{ route('home') }}#intro">Home</a></li>
                <li><a href="{{ route('home') }}#about">Whistleblowing</a></li>
                @if (session()->has(config('session.prefix') . '_id_user') && session(config('session.prefix') . '_id_user') != null)
                <li><a href="{{ route('pengaduan') }}" role="button">Laporkan</a></li>
                @else
                <li><a href="#" role="button" data-bs-target="#modalLogin" data-bs-toggle="modal">Laporkan</a></li>
                @endif
                <li><a href="{{ route('home') }}#faq">FAQ</a></li>
                <li><a href="{{ route('home') }}#contact">Hubungi Kami</a></li>
                @if (!session()->has(config('session.prefix') . '_id_user') || session(config('session.prefix') . '_id_user') == null)
                <li><a href="#" role="button" data-bs-target="#modalLogin" data-bs-toggle="modal">Login</a></li>
                @else
                <li><button type="button" href="{{ route('logout') }}" onclick="confirm_alert(this,event,'Apakah anda yakin akan meninggalkan sistem?')" class="btn btn-sm btn-danger me-2 py-1 px-2">Keluar</button></li>
                @endif
            </ul>
        </nav><!-- #nav-menu-container -->
    </div>
</header>