@extends('layouts.admin.main')

@push('script')
<script src="{{ asset('assets/admin/js/modul/dashboard/report.js') }}"></script>
@endpush


@section('content')

<!--begin::Container-->
<div class="container-xxl" id="kt_content_container">
    <!--begin::reports-->
    <div class="card card-flush">
        <!--begin::Card header-->
        <div class="card-header align-items-center py-5 gap-2 gap-md-5">
            <!--begin::Card title-->
            <div class="card-title">
                <!--begin::Search-->
                <div class="d-flex align-items-center position-relative my-1">
                    <i class="ki-duotone ki-magnifier fs-3 position-absolute ms-4">
                        <span class="path1"></span>
                        <span class="path2"></span>
                    </i>
                    <input type="text" class="form-control form-control-solid w-250px ps-12 search-datatable" placeholder="Search"  />
                </div>
                <!--end::Search-->
            </div>
            <!--end::Card title-->
            <!--begin::Card toolbar-->
            <div class="card-toolbar flex-row-fluid justify-content-end gap-5">
                <a href="{{ route('report.export') }}" target="_BLANK" class="btn btn-sm btn-success">Export Excel</a>
            </div>
            <!--end::Card toolbar-->
        </div>
        <!--end::Card header-->
        <!--begin::Card body-->
        <div class="card-body pt-0 table-responsive">
            <!--begin::Table-->
            <table class="table align-middle table-row-dashed fs-6 gy-5" id="table_report" data-url="{{ route('table.report') }}">
                <thead>
                    <tr class="text-start text-gray-500 fw-bold fs-7 text-uppercase gs-0">
                        <th class="text-end min-w-100px" data-orderable="false" data-searchable="false">Actions</th>
                        <th class="min-w-200px">Reporter</th>
                        <th class="min-w-150px">Category</th>
                        <th class="min-w-150px">Name 1</th>
                        <th class="min-w-150px">Name 2</th>
                        <th class="min-w-150px">Place</th>
                        <th class="min-w-100px">Date of Incident</th>
                        <th class="min-w-100px">Report Date</th>
                    </tr>
                </thead>
                <tbody class="fw-semibold text-gray-600">
                </tbody>
            </table>
            <!--end::Table-->
        </div>
        <!--end::Card body-->
    </div>
    <!--end::reports-->
</div>
<!--end::Container-->



<!-- Modal Tambah admin -->
<div class="modal fade" id="kt_modal_detail" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered mw-650px">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="title_modal">Detail Pengaduan</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Tutup"></button>
            </div>
            <div class="modal-body mx-5 mx-xl-15 my-7" id="display_detail">

            </div>
        </div>
    </div>
</div>
@endsection