@extends('layouts.user.main')



@push('styles')
<link href="{{ asset('assets/user/avilon/css/pengaduan.css') }}" rel="stylesheet">
@endpush

@push('script')
    

  <script type="text/javascript">

    document.body.style.background = 
  "linear-gradient(60deg, rgba(109, 109, 109, 0.21), rgba(92, 92, 92, 0.204)) 0% 0% / cover, url({{ image_check('1.jpg','banner') }}) center center fixed";

  </script>
@endpush

@section('content') 
<div class="container w-100 background-partisi" style="margin-top: 130px;">
        

<div class="container-fluid">
    <div class="stepwizard">
    </div>
    <form method="POST" action="{{ route('report.submit') }}" accept-charset="UTF-8" class="" id="form_laporan" role="form" enctype="multipart/form-data">


        <div class="panel panel-primary setup-content" id="step-1">
            <div class="panel-heading">
                <h3 class="panel-title">Data Laporan</h3>
            </div>
            <div class="panel-body">

            <div class="form-group" id="req_id_category">
                <select name="id_category" class="form-control select2-style" data-placeholder="Pilih kategori masalah">
                    <option></option>
                    @if($category && $category->isNotEmpty())
                    @foreach($category AS $row)
                    <option value="{{ $row->id_category }}">{{ $row->name }}</option>
                    @endforeach
                    @endif
                </select>
            </div>
            

            <div class="form-row">
                <div class="form-group col-lg-6" id="req_name_1">
                <input class="form-control" placeholder="Nama Terlapor 1" name="name_1" type="text">
                </div>
                <div class="form-group col-lg-6" id="req_name_2">
                <input class="form-control" placeholder="Nama Terlapor 2" name="name_2" type="text"> 
                </div>
            </div>

            <div class="form-row">
                <div class="form-group col-lg-6" id="req_place">
                <input class="form-control" placeholder="Tempat Kejadian" name="place" type="text">
                </div>
                <div class="form-group col-lg-6" id="req_date">
                <input class="form-control" placeholder="Waktu Kejadian" name="date" type="date">
                </div>
            </div>

            <div class="form-group" id="req_description">
                <textarea class="form-control" placeholder="Kronologis/Uraian" name="description" cols="50" rows="10"></textarea> 
            </div>

            <div class="form-row">
                <input multiple="multiple" name="file[]" class="form-control" type="file" id="formFile">
            </div>

            <button class="btn btn-primary nextBtn pull-right mt-3" type="button" id="button_laporan" onclick="submit_form(this,'#form_laporan')">Kirim Laporan</button>
        </div>

    </form>
    
</div>
</div>
@endsection