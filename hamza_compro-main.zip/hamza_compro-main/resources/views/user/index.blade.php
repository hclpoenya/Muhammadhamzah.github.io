@extends('layouts.user.main')
@section('content') 
<section id="intro" style="background : linear-gradient(60deg, rgba(109, 109, 109, 0.21), rgba(92, 92, 92, 0.204)) 0% 0% / cover, url({{ image_check('1.jpg','banner') }}) center center fixed;">

    <div class="intro-text">
        <h2>Selamat Datang di Whistleblowing </h2>
        <h2>PT IMSC </h2>
        <h2> </h2>
        <p>Apabila Anda Melihat, Mengalami atau Mengetahui Tindakan Pelanggaran oleh Karyawan IMSC</p>
        <!-- <a href="#about" class="btn-get-started">Laporkan</a> -->
    </div>
</section>

<section id="about" class="section-bg">
    <div class="container-fluid">
        <div class="section-header">
            <h3 class="section-title">Whistleblowing</h3>
            <span class="section-divider"></span>
            <p class="section-description">
                Whistleblowing System adalah aplikasi yang disediakan oleh PT IMSC  bagi Anda yang
                memiliki<br>
                informasi dan ingin melaporkan suatu perbuatan berindikasi pelanggaran yang dilakukan oleh INSAN
                IMSC
            </p>
        </div>
    </div>

    <section id="more-features" class="section-bg">
        <div class="container">

            <div class="section-header">
                <h3 class="section-title">Ruang Lingkup</h3>
                <span class="section-divider"></span>
            </div>

            <div class="row">

                @if($category && $category->isNotEmpty())
                @foreach($category AS $row)
                <div class="col-sm-4">
                    <div class="boxc wow fadeInLeft">

                        <h4 class="title" style="display: inline-block;line-height: 2.5;">
                            <a>{{ $row->name }}</a></h4>

                    </div>
                </div>
                @endforeach
                @endif

            </div>
        </div>
    </section>
</section>

<section id="call-to-action" style="background: linear-gradient(60deg, rgba(0, 0, 0, 0.212), rgba(0, 0, 0, 0.205)), url({{ image_check('1.jpg','banner') }}) fixed center center;">
    <div class="container">
        <div class="row">
            <div class="col-lg-9 text-center text-lg-left">
                <h3 class="cta-title">Laporkan Pelanggaran</h3>
                <p class="cta-text">Anda tidak perlu khawatir terungkapnya identitas diri anda karena PT IMSC
                    
                    akan <b>MERAHASIAKAN IDENTITAS DIRI ANDA</b> sebagai whistleblower. PT IMSC 
                    menghargai informasi yang Anda laporkan.
                    Fokus kami kepada materi informasi yang Anda Laporkan</p>
            </div>
            <div class="col-lg-3 cta-btn-container text-center">
                @if (session()->has(config('session.prefix') . '_id_user') && session(config('session.prefix') . '_id_user') != null)
                <a href="{{ route('pengaduan') }}" class="cta-btn align-middle cursor-pointer">Laporkan</a>
                @else
                <button class="cta-btn align-middle cursor-pointer" type="button" data-bs-target="#modalLogin" data-bs-toggle="modal">Laporkan</button>
                @endif
            </div>
        </div>

    </div>
</section>


<section id="faq" class="section-bg">
    <div class="container">

        <div class="section-header">
            <h3 class="section-title">Frequently Asked Questions</h3>
            <span class="section-divider"></span>

        </div>

        <ul id="faq-list" class="wow fadeInUp">

            <li>
                <a data-toggle="collapse" class="collapsed" href=#faq0>
                    Apakah aplikasi Whistle Blowing System (WBS) PT Industri Kereta Api ?
                    <i class="fa-solid fa-plus"></i></a>
                <div id=faq0 class="collapse" data-parent="#faq-list">
                    <ul>

                        <li>
                            <p>Aplikasi yang disediakan oleh PT IMSC  bagi Anda yang memiliki
                                informasi dan ingin melaporkan suatu perbuatan berindikasi pelanggaran
                                yang dilakukan oleh INSAN IMSC.</p>
                        </li>

                    </ul>
                </div>

            </li>

            <li>
                <a data-toggle="collapse" class="collapsed" href=#faq1>
                    Apakah kerahasiaan identitas saya sebagai pengadu/pelapor terjaga?
                    <i class="fa-solid fa-plus"></i></a>
                <div id=faq1 class="collapse" data-parent="#faq-list">
                    <ul>

                        <li>
                            <p>Anda tidak perlu khawatir terungkapnya identitas diri anda karena PT IMSC
                                 akan MERAHASIAKAN & MELINDUNGI Identitas Anda sebagai whistleblower.
                                PT IMSC  sangat menghargai informasi yang Anda laporkan. Fokus kami
                                kepada materi informasi yang Anda Laporkan. Sebagai bentuk terimakasih kami
                                terhadap laporan yang Anda kirim, kami berkomitmen untuk segera merespon laporan
                                Anda.</p>
                        </li>

                    </ul>
                </div>

            </li>

            <li>
                <a data-toggle="collapse" class="collapsed" href=#faq2>
                    Apakah bentuk respon yang diberikan kepada pelapor atas pengaduan yang disampaikan?
                    <i class="fa-solid fa-plus"></i></a>
                <div id=faq2 class="collapse" data-parent="#faq-list">
                    <ul>

                        <li>
                            <p>Respon yang diberikan kepada pelapor berupa status/tindak lanjut pengaduan paling
                                akhir sesuai dengan respon yang telah diberikan oleh pihak penerima pengaduan.
                                Respon terkait dengan status/tindak lanjut pengaduan dapat dilihat dalam history
                                pengaduan yang dikirimkan melalui email.</p>
                        </li>

                    </ul>
                </div>

            </li>

            <li>
                <a data-toggle="collapse" class="collapsed" href=#faq3>
                    Apakah manfaat dari Aplikasi Whistle Blowing System PT IMSC ?
                    <i class="fa-solid fa-plus"></i></a>
                <div id=faq3 class="collapse" data-parent="#faq-list">
                    <ul>

                        <li>
                            <p>Manfaat dari aplikasi Whistle Blowing System PT IMSC  yaitu fasilitas
                                bagi Unit Pengawasan Intern / Tim Pelaporan Pelanggaran untuk mendeteksi dini
                                adanya pelanggaran di unit-unit kerja, memberikan perlindungan pada pelapor,
                                fasilitas bagi pegawai, masyarakat atau pihak eksternal untuk mengadukan
                                penyimpangan secara mudah, mendorong partisipasi pegawai, masyarakat atau pihak
                                eksternal dalam upaya pencegahan dan pemberantasan KKN, mendorong terciptanya
                                INSAN IMSC berintegritas, dan mendorong percepatan birokrasi.</p>
                        </li>

                    </ul>
                </div>

            </li>


        </ul>

    </div>
</section>

<section id="contact">
    <div class="container">

        <div class="row wow fadeInUp">
            <div class="col-lg-12 col-md-4">
                <img src="{{ image_check('1.jpg','banner') }}" width="100%" height="100%"
                    alt="" title="">
            </div>
            <div class="col-lg-4 col-md-4">
                <br>
                <div class="contact-about text-center">
                    <h3><b>Hubungi Kami</b></h3>
                    <p>Tim Pelaporan Pelanggaran<br>
                        Surat Resmi:<br>
                        Direksi PT Industri Kereta Api <br>
                        u.p Direktur Keuangan dan SDM<br>
                        Jl. Yos Sudarso No. 71 Madiun 63122
                    </p>
                    <div class="social-links">
                        <a href="https://twitter.com/ptIMSC" class="twitter" target="_blank"><i
                                class="fa fa-twitter"></i></a>
                        <a href="https://www.facebook.com/ptIMSCpersero" class="facebook" target="_blank"><i
                                class="fa fa-facebook"></i></a>
                        <a href="https://www.instagram.com/pt_IMSC/" class="instagram" target="_blank"><i
                                class="fa fa-instagram"></i></a>
                        <!-- <a href="#" class="google-plus"><i class="fa fa-google-plus"></i></a> -->
                        <a href="https://www.linkedin.com/showcase/13311077/" class="linkedin"
                            target="_blank"><i class="fa fa-linkedin"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-md-4">
                <br>
                <div class="info">
                    <div>
                        <i style="font-size : 25px;" class="fa-solid fa-envelope"></i>
                        <p>whistleblowing@IMSC.co.id</p>
                    </div>

                    <div>
                        <i style="font-size : 25px;" class="fa-solid fa-phone"></i>
                        <p>(0351) 452271-74</p>
                    </div>

                    <div>
                        <i style="font-size : 25px;" class="fa-solid fa-phone"></i>
                        <p>(0351) 452275</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-5 col-md-8">
                <br>
                <div class="form">
                    <div id="sendmessage">Your message has been sent. Thank you!</div>
                    <div id="errormessage">Error</div>
                    <form action="{{ route('contact.insert') }}" method="post" role="form" class="contactForm" id="contactForm">
                        <div class="form-row">
                            <div class="form-group col-lg-6" id="req_contact_name">
                                <input type="text" name="name" class="form-control" id="name" placeholder="Nama"
                                    data-rule="minlen:4" data-msg="Please enter at least 4 chars" />
                                <div class="validation"></div>
                            </div>
                            <div class="form-group col-lg-6" id="req_contact_email">
                                <input type="email" class="form-control" name="email" id="email"
                                    placeholder="Email" data-rule="email"
                                    data-msg="Please enter a valid email" />
                                <div class="validation"></div>
                            </div>
                        </div>
                        <div class="form-group" id="req_contact_message">
                            <textarea class="form-control" name="message" id="message" rows="5"
                                data-rule="required" data-msg="Please write something for us"
                                placeholder="Pesan"></textarea>
                            <div class="validation"></div>
                        </div>
                        <div class="form-group">
                        </div>
                        <div class="text-center"><button type="button" id="button_contact" onclick="submit_form(this,'#contactForm')" title="Send Message">Kirim Pesan</button>
                        </div>
                    </form>
                </div>

            </div>

        </div>

    </div>
</section>
@endsection