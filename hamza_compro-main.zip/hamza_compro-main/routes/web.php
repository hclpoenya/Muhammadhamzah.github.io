<?php

use Illuminate\Support\Facades\Route;
use App\Http\Middleware\UserRoleAccess;
use App\Http\Middleware\DashboardRoleAccess;

use App\Http\Controllers\UserController;
use App\Http\Controllers\SettingController;
use App\Http\Controllers\AuthController;
use App\Http\Controllers\PaymentController;
use App\Http\Controllers\TableManagement;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\MasterController;
use App\Exports\ReportExport;
use Maatwebsite\Excel\Facades\Excel;

// AUTH PROSES
Route::get('/', function () {
    return redirect('/home');
});


// Halaman login hanya bisa diakses kalau BELUM login
Route::middleware(UserRoleAccess::class)->group(function () {
    // GET METHOD
    Route::get('/home', [UserController::class, 'index'])->name('home');
    Route::get('/pengaduan', [UserController::class, 'pengaduan'])->name('pengaduan');

    // POST METHOD
    Route::post('contact/insert', [UserController::class, 'insert_contact'])->name('contact.insert');
    Route::post('/register', [AuthController::class, 'register'])->name('auth.register');
    Route::post('/login', [AuthController::class, 'login'])->name('auth.login');
    Route::post('/update/profile', [UserController::class, 'update_profile'])->name('user.profile.update');
    Route::post('/submit/report', [UserController::class, 'submit_report'])->name('report.submit');

});

// Halaman dashboard hanya bisa diakses kalau SUDAH login
Route::middleware(DashboardRoleAccess::class)->group(function () {
    // GET METHOD (VIEW)

    // DASHBOARD CONTROLLER
    Route::controller(DashboardController::class)->group(function () {
        // DASHBOARD
        Route::get('/dashboard', 'index')->name('dashboard');
        // PROFILE
        Route::get('/profile', 'profile')->name('admin.profile');
        // CONTACT
        Route::get('/contact', 'contact')->name('contact');
         // REPORT
        Route::get('/report', 'report')->name('report');
    });
     // SETTING CONTROLLER
    Route::get('/setting', [SettingController::class, 'index'])->name('setting');
    // MASTER CONTROLLER
    Route::controller(MasterController::class)->group(function () {
        Route::get('/master/user', 'user')->name('master.user');
        Route::get('/master/admin', 'admin')->name('master.admin');
        Route::get('/master/category', 'category')->name('master.category');
       
    });


    


    //  POST METHOD

    // SETTING
    Route::post('/setting/logo', [SettingController::class, 'updateLogo'])->name('setting.logo');
    Route::post('/setting/seo', [SettingController::class, 'updateSeo'])->name('setting.seo');
    Route::post('/setting/sosmed', [SettingController::class, 'setupSosmed'])->name('setting.sosmed');
    Route::post('/setting/insert/sosmed', [SettingController::class, 'insert_sosmed'])->name('insert.sosmed');
    Route::post('/setting/update/sosmed', [SettingController::class, 'update_sosmed'])->name('update.sosmed');
    // DASHBOARD
    Route::controller(DashboardController::class)->group(function () {
         // PROFILE
        Route::post('/dashboard/updateEmail', 'updateEmail')->name('email.update');
        Route::post('/dashboard/updatePassword', 'updatePassword')->name('password.update');
        Route::post('/dashboard/accountDeactivated', 'accountDeactivated')->name('account.deactivated');
        Route::post('/dashboard/updateProfile', 'updateProfile')->name('admin.profile.update');
        Route::post('/detail/pengaduan', 'detail_pengaduan')->name('detail.pengaduan');
        
    });
  
    // DATATABLE
    Route::controller(TableManagement::class)->group(function () {
        // MASTER
        Route::post('/table/user', 'table_user')->name('table.user');
        Route::post('/table/admin', 'table_admin')->name('table.admin');
        // CATEGORY
        Route::post('/table/category', 'table_category')->name('table.category');
        // REPORT
        Route::post('/table/report', 'table_report')->name('table.report');
        // CONTACT
        Route::post('/table/contact', 'table_contact')->name('table.contact');
    });
    // MASTER CONTROLLER
    Route::controller(MasterController::class)->group(function () {
        // USER
        Route::post('/master/user/update', 'update_user')->name('update.user');
        Route::post('/master/user/insert', 'insert_user')->name('insert.user');
        // ADMIN
        Route::post('/master/admin/update', 'update_user')->name('update.admin');
        Route::post('/master/admin/insert', 'insert_user')->name('insert.admin');
         // CATEGORY
        Route::post('/master/category/update', 'update_category')->name('update.category');
        Route::post('/master/category/insert', 'insert_category')->name('insert.category');
    });

   

    // AJAX
    
    // DATATABLE

    // GLOBAL FUNCTION
    Route::post('/switch/{db?}', [SettingController::class, 'switch']);
    Route::post('/delete', [SettingController::class, 'hapusdata']);
    Route::post('/single/{db?}/{id?}', [SettingController::class, 'single']);
    
});



Route::get('/report/export', function () {
    return Excel::download(new ReportExport, 'Data-pelaporan-karyawan.xlsx');
})->name('report.export');


Route::post('/logout', [AuthController::class, 'logout'])->name('logout');
Route::get('/logout', [AuthController::class, 'logout'])->name('logout');