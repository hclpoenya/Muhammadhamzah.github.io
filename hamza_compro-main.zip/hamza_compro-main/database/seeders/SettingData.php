<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Setting;

class SettingData extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Setting::create([
            'id_setting' => 1,
            'logo' => 'logo.png',
            'logo_white' => '',
            'icon' => 'icon.png',
            'icon_white' => '',
            'meta_title' => 'IMSC',
            'meta_author' => 'Direksi PT Industri Kereta Api (Persero) u.p Direktur Keuangan dan SDM',
            'meta_keyword' => '',
            'meta_description' => '',
            'meta_address' => 'Jl. Yos Sudarso No. 71 Madiun 63122',
            'updated_at' => now(),
        ]);
    }
}
