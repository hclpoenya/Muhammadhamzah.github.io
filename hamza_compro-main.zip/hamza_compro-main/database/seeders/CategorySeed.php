<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Category;

class CategorySeed extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        Category::insert([
            [
                'name' => 'Penyalahgunaan dan Pemalsuan Data',
            ],
            [
                'name' => 'Penyalahgunaan Jabatan',
            ],
            [
                'name' => 'Pembocoran Rahasia',
            ],
            [
                'name' => 'Gratifikasi',
            ],
            [
                'name' => 'Penyelewengan Uang',
            ],
            [
                'name' => 'Penggelapan Aset',
            ],
            [
                'name' => 'Pemerasan',
            ],
            [
                'name' => 'Penipuan',
            ],
            [
                'name' => 'Benturan Kepentingan',
            ],
            [
                'name' => 'Pelanggaran Etika dan Perbuatan Asusila',
            ],
            [
                'name' => 'Korupsi',
            ],
            [
                'name' => 'Pencurian',
            ],
            [
                'name' => 'Kecurangan',
            ],
        ]);
    }
}
