<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB; // Tambahin ini

return new class extends Migration {
    public function up()
    {
        Schema::create('reports', function (Blueprint $table) {
            $table->id('id_report'); // AUTO_INCREMENT
            $table->unsignedBigInteger('id_category')->nullable();
            $table->unsignedBigInteger('id_user')->nullable();
            $table->string('name_1', 199)->nullable();
            $table->string('name_2', 199)->nullable();
            $table->string('place', 199)->nullable();
            $table->date('date')->nullable();
            $table->string('description', 199)->text();
            $table->dateTime('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
            $table->dateTime('updated_at')->default(DB::raw('CURRENT_TIMESTAMP'));
            $table->foreign('id_category')
                    ->references('id_category')->on('categories')
                    ->onUpdate('CASCADE')
                    ->onDelete('CASCADE');
            $table->foreign('id_user')
                    ->references('id_user')->on('users')
                    ->onUpdate('CASCADE')
                    ->onDelete('CASCADE');
        });
    }

    public function down()
    {
        Schema::dropIfExists('contacts');
    }
};
