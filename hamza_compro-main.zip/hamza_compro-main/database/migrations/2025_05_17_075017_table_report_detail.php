<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB;

return new class extends Migration {
    public function up()
    {
        Schema::create('report_details', function (Blueprint $table) {
            $table->id('id_report_detail'); // primary key untuk report_details
            $table->unsignedBigInteger('id_report'); // FK ke reports
            $table->string('file', 199)->nullable();

            $table->dateTime('created_at')->default(DB::raw('CURRENT_TIMESTAMP'));
            $table->dateTime('updated_at')->default(DB::raw('CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP'));

            // foreign key relasi ke tabel reports
            $table->foreign('id_report')
                  ->references('id_report')->on('reports')
                  ->onUpdate('CASCADE')
                  ->onDelete('CASCADE');
        });
    }

    public function down()
    {
        Schema::dropIfExists('report_details');
    }
};
